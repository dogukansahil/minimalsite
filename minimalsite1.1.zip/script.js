const sunButton = document.querySelector(".emoji-button");
const moonButton = document.createElement("button");
moonButton.innerHTML = "🌙";
moonButton.classList.add("emoji-button", "hidden");
sunButton.addEventListener("click", toggleNightMode);
moonButton.addEventListener("click", toggleDayMode);

function toggleNightMode() {
  const body = document.body;
  const h1 = document.querySelector("h1");
  const paragraphs = document.querySelectorAll("p");

  body.classList.add("night-mode");
  h1.classList.add("night-mode");
  paragraphs.forEach((p) => p.classList.add("night-mode"));

  sunButton.classList.add("hidden");
  moonButton.classList.remove("hidden");
}

function toggleDayMode() {
  const body = document.body;
  const h1 = document.querySelector("h1");
  const paragraphs = document.querySelectorAll("p");

  body.classList.remove("night-mode");
  h1.classList.remove("night-mode");
  paragraphs.forEach((p) => p.classList.remove("night-mode"));

  sunButton.classList.remove("hidden");
  moonButton.classList.add("hidden");
}

sunButton.insertAdjacentElement("afterend", moonButton);

const currentYear = new Date().getFullYear();
document.getElementById("current-year").textContent = currentYear;
